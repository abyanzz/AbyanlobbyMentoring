package com.abyan.mentoring.abyanlobbymentoring

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
